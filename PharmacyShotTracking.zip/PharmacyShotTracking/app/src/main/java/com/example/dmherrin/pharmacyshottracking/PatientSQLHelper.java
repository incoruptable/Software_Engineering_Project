package com.example.dmherrin.pharmacyshottracking;

/**
 * Created by dmherrin on 5/3/16.
 */
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import static com.example.dmherrin.pharmacyshottracking.PatientContract.PatientColumns.COLUMN_FIRST;
import static com.example.dmherrin.pharmacyshottracking.PatientContract.PatientColumns.TABLE_NAME;

public class PatientSQLHelper extends SQLiteOpenHelper {

    private static final String TAG = "MARKER";

    public PatientSQLHelper(Context context) {
        super(context, PatientContract.DATABASE_NAME,
                null, PatientContract.DATABASE_VERSION);
    }

    // when no database exists in disk and the helper class needs to create a new one.
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(PatientContract.PatientColumns.CREATE_TABLE);
    }

    // when there is a database version mismatch meaning that the version.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.w("TaskDBAdapter", "Upgrading from version " +
                oldVersion + " to " + newVersion + ". all data destroyed.");
        db.execSQL(PatientContract.PatientColumns.DELETE_TABLE);

        Log.d(TAG, "database dropped.");
        db.execSQL(PatientContract.PatientColumns.CREATE_TABLE);
    }

    // method for inserting MyMarker objects into the database
    public void insert(SQLiteDatabase db, String firstName, String lastName) {
        ContentValues values = new ContentValues();

        values.put(PatientContract.PatientColumns.COLUMN_FIRST, firstName);

        values.put(PatientContract.PatientColumns.COLUMN_LAST, lastName);

        db.insert(PatientContract.PatientColumns.TABLE_NAME, null, values);
    }

    public void remove(SQLiteDatabase db, String firstName) {

        db.execSQL("delete from " + TABLE_NAME + " where " + COLUMN_FIRST + " = '" + firstName + "'");
    }

}
