package com.example.dmherrin.pharmacyshottracking;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

/**
 * Created by dmherrin on 4/21/16.
 */
public class ForgottenPassword extends Activity {

    private String mActivityName;
    //private TextView mStatusView;
    //private TextView mStatusAllView;
    //private StatusTracker mStatusTracker = StatusTracker.getInstance();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgotten_password);
        mActivityName = getString(R.string.activity_forgotten_password);




        /*mStatusView = (TextView)findViewById(R.id.status_view_b);
        mStatusAllView = (TextView)findViewById(R.id.status_view_all_b);
        mStatusTracker.setStatus(mActivityName, getString(R.string.on_create));
        Utils.printStatus(mStatusView, mStatusAllView);*/
    }

    @Override
    protected void onStart() {
        super.onStart();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_start));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_restart));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_resume));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_pause));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onStop() {
        super.onStop();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_stop));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_destroy));
    }






    public void exitForgottenPassword(View v) {
        ForgottenPassword.this.finish();
    }
}
