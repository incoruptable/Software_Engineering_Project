package com.example.dmherrin.pharmacyshottracking;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class PatientSearch extends Activity {

    private static final String TAG = "Patient";
    private String mActivityName;
    //private TextView mStatusView;
    //private TextView mStatusAllView;
    //private StatusTracker mStatusTracker = StatusTracker.getInstance();
    private PatientSQLHelper patientHelper;
    private SQLiteDatabase patientDB;
    String[] cols = {PatientContract.PatientColumns.COLUMN_FIRST, PatientContract.PatientColumns.COLUMN_LAST};
    ArrayList<Patient> patientArrayList;
    ArrayAdapter<Patient> patientArrayAdapter;
    public ListView lv;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_search);
        mActivityName = getString(R.string.activity_patient_search);
        lv = (ListView) findViewById(R.id.listView);
        /*mStatusView = (TextView)findViewById(R.id.status_view_b);
        mStatusAllView = (TextView)findViewById(R.id.status_view_all_b);
        mStatusTracker.setStatus(mActivityName, getString(R.string.on_create));
        Utils.printStatus(mStatusView, mStatusAllView);*/
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.searchparams_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        patientArrayList = new ArrayList<>();




        patientHelper = new PatientSQLHelper(this);
        patientDB = patientHelper.getWritableDatabase();

    }

    @Override
    protected void onStart() {
        super.onStart();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_start));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_restart));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_resume));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_pause));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onStop() {
        super.onStop();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_stop));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_destroy));
    }

    /*public void startLoginFrame(View v) {
        Intent intent = new Intent(MainFrame.this, LoginFrame.class);
        startActivity(intent);
    }
*/
    public ArrayList<Patient> getMyPatient(){
        ArrayList<Patient> patients = new ArrayList<Patient>();

        Cursor cursor = patientDB.query(PatientContract.PatientColumns.TABLE_NAME, cols, null, null, null, null, null);
        cursor.moveToFirst();
        while(!cursor.isAfterLast())
        {
            Patient f = cursorToPatient(cursor);
            patients.add(f);
            cursor.moveToNext();
        }
        cursor.close();

        return patients;
    }

    private Patient cursorToPatient(Cursor cursor) {
        Patient f = new Patient();
        f.setFirstName(cursor.getString(0));
        f.setLastName(cursor.getString(1));
        return f;
    }

    public void searchPatients(View v)
    {
        patientArrayList = getMyPatient();
        patientArrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, patientArrayList);
        lv.setAdapter(patientArrayAdapter);
    }

    public void exitPatientSearch(View v) {
        PatientSearch.this.finish();
    }
}

