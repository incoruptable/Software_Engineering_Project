package com.example.dmherrin.pharmacyshottracking;

import android.app.Activity;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

public class Profile extends Activity {

    private String mActivityName;
    //private TextView mStatusView;
    //private TextView mStatusAllView;
    //private StatusTracker mStatusTracker = StatusTracker.getInstance();
    EditText first;
    EditText last;
    String f;
    String l;
    private PatientSQLHelper patientHelper;
    private SQLiteDatabase patientDB;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        mActivityName = getString(R.string.activity_profile);

        Spinner spinner = (Spinner) findViewById(R.id.spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.states_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);


        patientHelper = new PatientSQLHelper(this);
        patientDB = patientHelper.getWritableDatabase();


        /*mStatusView = (TextView)findViewById(R.id.status_view_b);
        mStatusAllView = (TextView)findViewById(R.id.status_view_all_b);
        mStatusTracker.setStatus(mActivityName, getString(R.string.on_create));
        Utils.printStatus(mStatusView, mStatusAllView);*/
    }

    @Override
    protected void onStart() {
        super.onStart();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_start));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_restart));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_resume));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onPause() {
        super.onPause();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_pause));
        //Utils.printStatus(mStatusView, mStatusAllView);
    }

    @Override
    protected void onStop() {
        super.onStop();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_stop));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        //mStatusTracker.setStatus(mActivityName, getString(R.string.on_destroy));
    }

    public void createPatient(View v){
        first   = (EditText)findViewById(R.id.editText2);
        last = (EditText)findViewById(R.id.editText3);
        f = first.getText().toString();
        l = last.getText().toString();

        patientHelper.insert(patientDB, f, l);



    }






    public void exitProfile(View v) {
        Profile.this.finish();
    }
}
