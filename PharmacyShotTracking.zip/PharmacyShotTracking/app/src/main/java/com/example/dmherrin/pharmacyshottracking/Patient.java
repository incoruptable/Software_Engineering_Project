package com.example.dmherrin.pharmacyshottracking;

/**
 * Created by dmherrin on 5/3/16.
 */
public class Patient {
    private String firstName;
    private String lastName;


    public Patient() {}
    public Patient(String f, String l) {
        firstName = f; lastName = l;
    }



    public String getFirstName()     {return firstName;}
    public String getLastName() {return lastName;}

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String toString() {
        return "First Name:\t" + firstName + "\nLast Name:\t" + lastName;
    }
}
