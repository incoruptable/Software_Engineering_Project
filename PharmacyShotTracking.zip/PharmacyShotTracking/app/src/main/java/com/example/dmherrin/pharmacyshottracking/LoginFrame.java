package com.example.dmherrin.pharmacyshottracking;


import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

/**
 * Created by dmherrin on 4/21/16.
 */
public class LoginFrame extends Activity {


    //private DAO dao;





    @Override
    public void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_frame);
    }

    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onStop() {
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    public void startMainFrame(View v) {
        Intent intent = new Intent(LoginFrame.this, MainFrame.class);
        startActivity(intent);

        /*ResultSet rs;
        try {
            EditText user = (EditText)findViewById(R.id.username);
            EditText pass = (EditText)findViewById(R.id.password);
            dao = new DAO();
            String userName = user.getText().toString();
            String passWord = pass.getText().toString();
            dao.setquery("SELECT * FROM dbo.LoginPage WHERE username = ? AND password = ?");
            dao.SetParameter(userName);
            dao.SetParameter(passWord);
            dao.setExpectRS(true);
            rs = dao.executeQuery();
            if(rs.next()) {
                do{
                    System.out.println("Inside while loop");
                    if(rs.getString(2).equals(String.valueOf(passWord))){
                        System.out.println("Account accepted");
                        Context context = getApplicationContext();
                        CharSequence text = "Account accepted";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                        Intent intent = new Intent(LoginFrame.this, MainFrame.class);
                        startActivity(intent);
                        return;
                    }
                    else
                    {
                        Context context = getApplicationContext();
                        CharSequence text = "Username or Password Incorrect\r\nPlease try again.";
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }

                } while(rs.next());
            }
            else{
                Context context = getApplicationContext();
                CharSequence text = "Username or Pasword Incorrect\r\nPlease try again.";
                int duration = Toast.LENGTH_SHORT;

                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }*/
    }

    public void startForgottenPassword(View v) {
        Intent intent = new Intent(LoginFrame.this, ForgottenPassword.class);
        startActivity(intent);
    }



}

