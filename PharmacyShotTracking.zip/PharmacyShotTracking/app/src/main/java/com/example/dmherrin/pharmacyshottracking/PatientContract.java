package com.example.dmherrin.pharmacyshottracking;

/**
 * Created by dmherrin on 5/3/16.
 */
import android.provider.BaseColumns;

public final class PatientContract {

    public static final int    DATABASE_VERSION    = 2;
    public static final String DATABASE_NAME       = "patients.db";
    public static final String TEXT_TYPE           = " TEXT";
    public static final String COMMA_SEP           = ", ";

    // To prevent someone from accidentally instantiating the contract class,
    // give it an empty private constructor.
    private PatientContract() {}

    /* Inner class that defines the table contents */
    public static abstract class PatientColumns implements BaseColumns {

        public static final String TABLE_NAME   = "patientTable";
        public static final String COLUMN_FIRST   = "firstName";
        public static final String COLUMN_LAST   = "lastName";


        public static final String CREATE_TABLE =
                "CREATE TABLE " + TABLE_NAME + " (" +
                        _ID + " INTEGER PRIMARY KEY, " +
                        COLUMN_FIRST + TEXT_TYPE + "," +
                        COLUMN_LAST + TEXT_TYPE + ")";
        public static final String DELETE_TABLE = "DROP TABLE IF EXISTS " + TABLE_NAME;
    }

}

